from enum import Enum
from pydantic import BaseModel
from typing import Optional

class Status(str, Enum):
    ON = "ON"
    OFF = "OFF"
    POSSIBLE = "POSSIBLE"
    UNKNOWN = "UNKNOWN"

class Interval(BaseModel):
    start: str
    end: str
    status: Status

class DaySchedule(BaseModel):
    date: str
    intervals: list[Interval]

class Source(BaseModel):
    provider: str
    source_type: str = "official"
    fetched_at: Optional[str] = None

class OutageResponse(BaseModel):
    region: str
    operator: str
    group: str
    days: list[DaySchedule]
    source: Source
