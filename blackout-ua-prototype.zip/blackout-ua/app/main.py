from fastapi import FastAPI, HTTPException
from app.providers.yasno import YasnoProvider, REGIONS

app = FastAPI(title="Blackout UA API", version="0.1.0")

@app.get("/health")
async def health():
    return {"ok": True, "version": "0.1.0"}

@app.get("/api/v1/regions")
async def regions():
    return [{"id": k, **v} for k, v in REGIONS.items()]

@app.get("/api/v1/outages/{region}/{group}")
async def outages(region: str, group: str):
    if region not in REGIONS:
        raise HTTPException(404, "Unsupported region")
    try:
        return await YasnoProvider().get_schedule(region, group)
    except Exception as e:
        raise HTTPException(502, f"Upstream provider error: {type(e).__name__}")
