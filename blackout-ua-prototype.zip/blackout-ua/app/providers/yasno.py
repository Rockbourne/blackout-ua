import httpx
from datetime import datetime, timezone
from app.models import OutageResponse, DaySchedule, Interval, Status, Source
from app.providers.base import Provider

BASE = "https://app.yasno.ua/api/blackout-service/public/shutdowns"

# Mapping is deliberately configuration, not hard-coded business logic.
REGIONS = {
    "kyiv": {"region_id": 25, "dso_id": 902, "operator": "yasno-dtek-kem"},
    "dnipro-dtek": {"region_id": 3, "dso_id": 301, "operator": "yasno-dtek-dnem"},
    "dnipro-cek": {"region_id": 3, "dso_id": 303, "operator": "yasno-cek"},
}

class YasnoProvider(Provider):
    async def get_schedule(self, region: str, group: str) -> OutageResponse:
        cfg = REGIONS[region]
        url = f"{BASE}/regions/{cfg['region_id']}/dsos/{cfg['dso_id']}/planned-outages"
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(url)
            r.raise_for_status()
            raw = r.json()
        days = normalize_yasno(raw, group)
        return OutageResponse(region=region, operator=cfg["operator"], group=group,
            days=days, source=Source(provider="YASNO", fetched_at=datetime.now(timezone.utc).isoformat()))

def normalize_yasno(raw: dict, group: str) -> list[DaySchedule]:
    # YASNO has changed response envelopes before. Keep parsing defensive.
    node = raw.get(group) or raw.get("data", {}).get(group) or {}
    out = []
    for day_key, day in node.items():
        if not isinstance(day, dict):
            continue
        date = day.get("date") or day_key
        intervals = []
        for slot in day.get("slots", []):
            kind = str(slot.get("type", "")).lower()
            status = Status.UNKNOWN
            if kind in {"notplanned", "yes", "on"}: status = Status.ON
            elif kind in {"planned", "no", "off"}: status = Status.OFF
            elif kind in {"maybe", "possible", "first", "second", "mfirst", "msecond"}: status = Status.POSSIBLE
            intervals.append(Interval(start=_time(slot.get("start")), end=_time(slot.get("end")), status=status))
        if intervals:
            out.append(DaySchedule(date=str(date), intervals=intervals))
    return out

def _time(v):
    if isinstance(v, int):
        return f"{v//60:02d}:{v%60:02d}"
    return str(v)
