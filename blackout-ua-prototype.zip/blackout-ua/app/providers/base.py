from abc import ABC, abstractmethod
from app.models import OutageResponse

class Provider(ABC):
    @abstractmethod
    async def get_schedule(self, region: str, group: str) -> OutageResponse:
        raise NotImplementedError
