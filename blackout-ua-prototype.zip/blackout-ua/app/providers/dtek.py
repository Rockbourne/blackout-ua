# Adapter boundary for DTEK WordPress AJAX.
# Production access may require WAF-cleared cookies; keeping it isolated prevents
# the public Blackout UA API from depending on DTEK's frontend protocol.
from app.providers.base import Provider

class DtekProvider(Provider):
    async def get_schedule(self, region: str, group: str):
        raise RuntimeError("DTEK live adapter requires WAF session integration")
