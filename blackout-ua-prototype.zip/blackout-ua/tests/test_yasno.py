from app.providers.yasno import normalize_yasno

def test_normalize_minutes():
    raw = {"3.1": {"2026-09-24": {"slots": [
        {"start": 480, "end": 600, "type": "Planned"},
        {"start": 600, "end": 720, "type": "NotPlanned"}
    ]}}}
    d = normalize_yasno(raw, "3.1")[0]
    assert d.intervals[0].start == "08:00"
    assert d.intervals[0].status.value == "OFF"
    assert d.intervals[1].status.value == "ON"
